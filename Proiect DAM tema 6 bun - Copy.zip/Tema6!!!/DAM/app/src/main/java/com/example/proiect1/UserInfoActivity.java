package com.example.proiect1;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class UserInfoActivity extends AppCompatActivity {

    private EditText etName, etEmail;
    private Button btnSubmit;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> userList;
    private boolean isEditing = false;
    private int editPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        btnSubmit = findViewById(R.id.btn_submit);
        listView = findViewById(R.id.list_view_user_history);

        userList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userList);
        listView.setAdapter(adapter);

        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty()) {
                Toast.makeText(UserInfoActivity.this, "Toate câmpurile sunt obligatorii!", Toast.LENGTH_SHORT).show();
                return;
            }

            String userDetails = "Nume: " + name + ", Email: " + email;

            if (isEditing) {
                userList.set(editPosition, userDetails);
                isEditing = false;
                editPosition = -1;
            } else {
                userList.add(userDetails);
            }

            adapter.notifyDataSetChanged();
            clearFields();
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedUser = userList.get(position);
            String[] parts = selectedUser.split(", ");

            String name = parts[0].replace("Nume: ", "").trim();
            String email = parts[1].replace("Email: ", "").trim();

            etName.setText(name);
            etEmail.setText(email);

            isEditing = true;
            editPosition = position;
        });
    }

    private void clearFields() {
        etName.setText("");
        etEmail.setText("");
    }
}
