package com.example.proiect1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AppSettingsPrefs";
    private static final String PREF_NOTIFICATIONS = "notifications_enabled";
    private static final String PREF_VOLUME = "volume_level";
    private static final String PREF_THEME = "selected_theme";

    private Switch switchNotifications;
    private SeekBar seekBarVolume;
    private Spinner spinnerTheme;
    private Button btnSaveSettings;
    private ListView listView;

    private SettingsAdapter adapter;
    private List<String> settingsList;
    private boolean isEditing = false;
    private int editPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        switchNotifications = findViewById(R.id.switch_notifications);
        seekBarVolume = findViewById(R.id.seekbar_volume);
        spinnerTheme = findViewById(R.id.spinner_theme);
        btnSaveSettings = findViewById(R.id.btn_save_settings);
        listView = findViewById(R.id.list_view_previous_settings);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.theme_options, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTheme.setAdapter(spinnerAdapter);

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        settingsList = new ArrayList<>();
        adapter = new SettingsAdapter(this, settingsList);
        listView.setAdapter(adapter);

        btnSaveSettings.setOnClickListener(v -> {
            boolean notificationsEnabled = switchNotifications.isChecked();
            int volume = seekBarVolume.getProgress();
            String theme = spinnerTheme.getSelectedItem().toString();

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(PREF_NOTIFICATIONS, notificationsEnabled);
            editor.putInt(PREF_VOLUME, volume);
            editor.putString(PREF_THEME, theme);
            editor.apply();

            String settings = "Notificări: " + (notificationsEnabled ? "Activ" : "Inactiv") +
                    ", Volum: " + volume +
                    ", Temă: " + theme;

            if (isEditing) {
                settingsList.set(editPosition, settings);
                isEditing = false;
                editPosition = -1;
            } else {
                settingsList.add(settings);
            }

            adapter.notifyDataSetChanged();
            Toast.makeText(SettingsActivity.this, "Setări salvate!", Toast.LENGTH_SHORT).show();
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            isEditing = true;
            editPosition = position;

            String selectedSetting = settingsList.get(position);
            String[] parts = selectedSetting.split(", ");

            boolean notifications = parts[0].contains("Activ");
            int volume = Integer.parseInt(parts[1].replaceAll("\\D+", ""));
            String theme = parts[2].split(": ")[1];

            switchNotifications.setChecked(notifications);
            seekBarVolume.setProgress(volume);
            int spinnerPosition = spinnerAdapter.getPosition(theme);
            spinnerTheme.setSelection(spinnerPosition);
        });
    }
}
