package com.example.proiect1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OrderHistoryAdapter extends ArrayAdapter<Order> {
    private final Context context;
    private final List<Order> orders;
    private final List<Order> originalOrders;

    public OrderHistoryAdapter(Context context, List<Order> orders) {
        super(context, R.layout.order_item, orders);
        this.context = context;
        this.orders = orders;
        this.originalOrders = new ArrayList<>(orders);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.order_item, parent, false);
        }

        TextView orderDate = convertView.findViewById(R.id.order_date);
        TextView orderPrice = convertView.findViewById(R.id.order_price);
        TextView orderAddress = convertView.findViewById(R.id.order_address);

        Order order = orders.get(position);

        orderDate.setText(order.getOrderDate());
        orderPrice.setText(String.format("%.2f RON", order.getTotalPrice()));
        orderAddress.setText(order.getDeliveryAddress());

        return convertView;
    }

    public void filterOrders(String query) {
        query = query.toLowerCase(Locale.getDefault());
        orders.clear();
        if (query.isEmpty()) {
            orders.addAll(originalOrders);
        } else {
            for (Order order : originalOrders) {
                if (order.getOrderDate().toLowerCase(Locale.getDefault()).contains(query) ||
                        order.getDeliveryAddress().toLowerCase(Locale.getDefault()).contains(query)) {
                    orders.add(order);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void addOrder(Order order) {
        orders.add(order);
        originalOrders.add(order);
        notifyDataSetChanged();
        Toast.makeText(context, "Comanda a fost adăugată cu succes!", Toast.LENGTH_SHORT).show();
    }
}
