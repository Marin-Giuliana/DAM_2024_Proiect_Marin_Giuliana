package com.example.proiect1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OrderHistoryActivity extends AppCompatActivity {

    private EditText etOrderDate, etTotalPrice, etDeliveryAddress;
    private Button btnSaveOrder;
    private ListView listViewOrderHistory;
    private OrderHistoryAdapter orderHistoryAdapter;
    private List<Order> orderList;
    private boolean isEditing = false;
    private int editPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        etOrderDate = findViewById(R.id.etOrderDate);
        etTotalPrice = findViewById(R.id.etTotalPrice);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        btnSaveOrder = findViewById(R.id.btnSaveOrder);
        listViewOrderHistory = findViewById(R.id.listViewOrderHistory);

        orderList = new ArrayList<>();
        orderHistoryAdapter = new OrderHistoryAdapter(this, orderList);
        listViewOrderHistory.setAdapter(orderHistoryAdapter);

        btnSaveOrder.setOnClickListener(v -> {
            String orderDate = etOrderDate.getText().toString().trim();
            String totalPriceStr = etTotalPrice.getText().toString().trim();
            String deliveryAddress = etDeliveryAddress.getText().toString().trim();

            if (orderDate.isEmpty() || totalPriceStr.isEmpty() || deliveryAddress.isEmpty()) {
                Toast.makeText(OrderHistoryActivity.this, "Toate câmpurile sunt obligatorii!", Toast.LENGTH_SHORT).show();
                return;
            }

            double totalPrice;
            try {
                totalPrice = Double.parseDouble(totalPriceStr);
            } catch (NumberFormatException e) {
                Toast.makeText(OrderHistoryActivity.this, "Prețul total trebuie să fie un număr valid!", Toast.LENGTH_SHORT).show();
                return;
            }

            Order newOrder = new Order(orderDate, totalPrice, deliveryAddress);

            if (isEditing) {
                orderList.set(editPosition, newOrder);
                isEditing = false;
                editPosition = -1;
            } else {
                orderList.add(newOrder);
            }

            orderHistoryAdapter.notifyDataSetChanged();
            clearFields();
        });

        listViewOrderHistory.setOnItemClickListener((parent, view, position, id) -> {
            Order selectedOrder = orderList.get(position);

            etOrderDate.setText(selectedOrder.getOrderDate());
            etTotalPrice.setText(String.format(Locale.getDefault(), "%.2f", selectedOrder.getTotalPrice()));
            etDeliveryAddress.setText(selectedOrder.getDeliveryAddress());

            isEditing = true;
            editPosition = position;
        });
    }

    private void clearFields() {
        etOrderDate.setText("");
        etTotalPrice.setText("");
        etDeliveryAddress.setText("");
    }
}
