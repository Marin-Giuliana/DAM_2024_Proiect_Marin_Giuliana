package com.example.proiect1;

import java.io.Serializable;

public class Order implements Serializable {
    private String orderDate;
    private double totalPrice;
    private String deliveryAddress;

    public Order(String orderDate, double totalPrice, String deliveryAddress) {
        this.orderDate = orderDate;
        this.totalPrice = totalPrice;
        this.deliveryAddress = deliveryAddress;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    @Override
    public String toString() {
        return "Order{" +
                "Data Comenzii ='" + orderDate + '\'' +
                ", Valoare Totala =" + totalPrice +
                ", Adresa de livrare ='" + deliveryAddress + '\'' +
                '}';
    }

    public String getDate() {
        return orderDate;
    }
}
