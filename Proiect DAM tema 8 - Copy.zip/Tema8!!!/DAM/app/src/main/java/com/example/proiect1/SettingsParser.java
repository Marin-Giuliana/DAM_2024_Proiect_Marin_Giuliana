package com.example.proiect1;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SettingsParser {

    public static List<Settings> parseSettings(String json) {
        List<Settings> settingsList = new ArrayList<>();

        try {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                Long idSettings = jsonObject.has("idSettings") ? jsonObject.getLong("idSettings") : null;
                boolean notificationsEnabled = jsonObject.getBoolean("notificationsEnabled");
                int volume = jsonObject.getInt("volume");
                String theme = jsonObject.getString("theme");

                Settings settings = new Settings(notificationsEnabled, volume, theme);
                settings.setIdSettings(idSettings);

                settingsList.add(settings);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return settingsList;
    }
}
