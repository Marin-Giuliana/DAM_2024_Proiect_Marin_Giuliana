package com.example.proiect1;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserParser {

    public static List<User> parseUsers(String json) {
        List<User> users = new ArrayList<>();

        try {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                Long idUsers = jsonObject.getLong("idUsers");
                String name = jsonObject.getString("name");
                String email = jsonObject.getString("email");
                String password = jsonObject.getString("password");
                String deliveryAdress = jsonObject.getString("deliveryAdress");

                User user = new User(name, email, password, deliveryAdress);
                user.setIdUsers(idUsers);

                users.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return users;
    }
}
