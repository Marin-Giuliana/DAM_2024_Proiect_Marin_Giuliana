package com.example.proiect1;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class OrderParser {

    public static List<Order> parseOrders(String json) {
        List<Order> orders = new ArrayList<>();

        try {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                Long idOrders = jsonObject.getLong("idOrders");
                Long userId = jsonObject.getLong("userId");
                String orderDate = jsonObject.getString("orderDate");
                double totalPrice = jsonObject.getDouble("totalPrice");
                String deliveryAddress = jsonObject.getString("deliveryAddress");

                Order order = new Order(userId, orderDate, totalPrice, deliveryAddress);
                order.setIdOrders(idOrders);

                orders.add(order);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return orders;
    }
}
