package com.example.proiect1;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName="Settings")
public class Settings implements Serializable {
    @PrimaryKey(autoGenerate=true)

    private Long idSettings;
    private boolean notificationsEnabled;
    private int volume;
    private String theme;


    public Settings(boolean notificationsEnabled, int volume, String theme) {
        this.notificationsEnabled = notificationsEnabled;
        this.volume = volume;
        this.theme = theme;
    }

    public Long getIdSettings() {
        return idSettings;
    }

    public void setIdSettings(Long idSettings) {
        this.idSettings = idSettings;
    }

    public boolean isNotificationsEnabled() {
        return notificationsEnabled;
    }

    public void setNotificationsEnabled(boolean notificationsEnabled) {
        this.notificationsEnabled = notificationsEnabled;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    @Override
    public String toString() {
        return "Settings{" +
                "idSettings=" + idSettings +
                ", notificationsEnabled=" + notificationsEnabled +
                ", volume=" + volume +
                ", theme='" + theme + '\'' +
                '}';
    }
}

