package com.example.proiect1;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(
        tableName = "Orders",
        foreignKeys = @ForeignKey(
                entity = User.class,
                parentColumns = "idUsers",
                childColumns = "userId",
                onDelete = ForeignKey.CASCADE
        )
)
public class Order implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private Long idOrders;
    private Long userId;
    private String orderDate;
    private double totalPrice;
    private String deliveryAddress;

    public Order(Long userId, String orderDate, double totalPrice, String deliveryAddress) {
        this.userId = userId;
        this.orderDate = orderDate;
        this.totalPrice = totalPrice;
        this.deliveryAddress = deliveryAddress;
    }


    public Long getIdOrders() {
        return idOrders;
    }

    public void setIdOrders(Long idOrders) {
        this.idOrders = idOrders;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
    @Override
    public String toString() {
        return "Order{" +
                "idOrders=" + idOrders +
                ", userId=" + userId +
                ", orderDate='" + orderDate + '\'' +
                ", totalPrice=" + totalPrice +
                ", deliveryAddress='" + deliveryAddress + '\'' +
                '}';
    }
}
