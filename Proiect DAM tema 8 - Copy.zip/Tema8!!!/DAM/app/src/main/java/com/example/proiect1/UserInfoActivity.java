package com.example.proiect1;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class UserInfoActivity extends AppCompatActivity {

    private EditText etName, etEmail;
    private ListView listView;
    private UserInfoAdapter adapter;
    private List<User> userList;

    private AppDatabase db;
    private UserDAO userDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        listView = findViewById(R.id.list_view_user_history);

        db = AppDatabase.getInstance(this);
        userDAO = db.getUserDAO();

        userList = new ArrayList<>();
        adapter = new UserInfoAdapter(this, userList);
        listView.setAdapter(adapter);

        parseAndSaveUsers();

        loadUsersFromDatabase();
    }

    private void loadUsersFromDatabase() {
        new Thread(() -> {
            List<User> users = userDAO.getAllUsers();
            System.out.println("Loaded users from DB: " + users);
            runOnUiThread(() -> {
                userList.clear();
                userList.addAll(users);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }


    private void parseAndSaveUsers() {
        new Thread(() -> {
           try {
               // String json = "[{\"idUsers\":1, \"name\":\"Popescu Ion\", \"email\":\"ipopescu@gmail.com\", \"password\":\"1234\", \"deliveryAdress\":\"Strada 1\"}, " +
                        //"{\"idUsers\":2, \"name\":\"Ionescu Adrian\", \"email\":\"aionescu@gmail.com\", \"password\":\"abcd\", \"deliveryAdress\":\"Strada 2\"}]";

                //List<User> users = UserParser.parseUsers(json);

                //for (User user : users) {
                 //   userDAO.insertUser(user);
                //}

                runOnUiThread(() -> Toast.makeText(this, "Utilizatorii au fost salvați din JSON!", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Eroare la parsarea JSON-ului!", Toast.LENGTH_SHORT).show());
                e.printStackTrace();
            }
        }).start();
    }
}
