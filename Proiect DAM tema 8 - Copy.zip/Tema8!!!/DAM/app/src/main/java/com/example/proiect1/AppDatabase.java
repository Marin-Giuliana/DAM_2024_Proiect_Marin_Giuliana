package com.example.proiect1;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities ={User.class, Order.class, Settings.class}, version=1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase{

    private static AppDatabase dbInstance;

    public static final String databaseName ="app.db";

    public static AppDatabase getInstance(Context context)
    {
        if(dbInstance==null)
            dbInstance = Room.databaseBuilder(context, AppDatabase.class, databaseName)
                    .fallbackToDestructiveMigration().build();

        return dbInstance;
    }

    public abstract UserDAO getUserDAO();
    public abstract OrderDAO getOrderDAO();
    public abstract SettingsDAO getSettingsDao();

}
