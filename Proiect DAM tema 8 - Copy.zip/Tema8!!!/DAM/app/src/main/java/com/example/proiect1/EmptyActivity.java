package com.example.proiect1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class EmptyActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AppSettingsPrefs";
    private static final String PREF_NOTIFICATIONS = "notifications_enabled";
    private static final String PREF_VOLUME = "volume_level";
    private static final String PREF_THEME = "selected_theme";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean notificationsEnabled = sharedPreferences.getBoolean(PREF_NOTIFICATIONS, false);
        int volume = sharedPreferences.getInt(PREF_VOLUME, 0);
        String theme = sharedPreferences.getString(PREF_THEME, "Default");


        Toast.makeText(this, "Notificări: " + (notificationsEnabled ? "Activ" : "Inactiv") +
                ", Volum: " + volume + ", Temă: " + theme, Toast.LENGTH_LONG).show();


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOptionsMenu(v);
            }
        });
    }

    private void showOptionsMenu(View anchor) {
        PopupMenu popupMenu = new PopupMenu(this, anchor);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.menu_user_info) {
                    Intent userDetailsIntent = new Intent(EmptyActivity.this, UserInfoActivity.class);
                    startActivity(userDetailsIntent);
                } else if (itemId == R.id.menu_order_history) {
                    Intent orderHistoryIntent = new Intent(EmptyActivity.this, OrderHistoryActivity.class);
                    startActivity(orderHistoryIntent);
                } else if (itemId == R.id.menu_settings) {
                    Intent settingsIntent = new Intent(EmptyActivity.this, SettingsActivity.class);
                    startActivity(settingsIntent);
                }
                return true;
            }
        });
        popupMenu.show();
    }
}
