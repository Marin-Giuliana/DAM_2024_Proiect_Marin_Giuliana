package com.example.proiect1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AppSettingsPrefs";
    private static final String PREF_NOTIFICATIONS = "notifications_enabled";
    private static final String PREF_VOLUME = "volume_level";
    private static final String PREF_THEME = "selected_theme";

    private Switch switchNotifications;
    private SeekBar seekBarVolume;
    private Spinner spinnerTheme;
    private Button btnSaveSettings;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> settingsList;

    private AppDatabase db;
    private SettingsDAO settingsDAO;
    private boolean isEditing = false;
    private Long editSettingId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        switchNotifications = findViewById(R.id.switch_notifications);
        seekBarVolume = findViewById(R.id.seekbar_volume);
        spinnerTheme = findViewById(R.id.spinner_theme);
        btnSaveSettings = findViewById(R.id.btn_save_settings);
        listView = findViewById(R.id.list_view_previous_settings);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.theme_options, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTheme.setAdapter(spinnerAdapter);

        settingsList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, settingsList);
        listView.setAdapter(adapter);

        db = AppDatabase.getInstance(this);
        settingsDAO = db.getSettingsDao();

        loadPreferences();

        parseAndSaveSettings();

        loadSettingsFromDatabase();

        btnSaveSettings.setOnClickListener(v -> saveSettings());

        listView.setOnItemClickListener((parent, view, position, id) -> editSettings(position));
    }

    private void parseAndSaveSettings() {
        new Thread(() -> {
            try {

                //String json = "[{\"idSettings\":10, \"notificationsEnabled\":true, \"volume\":50, \"theme\":\"închisă\"}, " +
                        //"{\"idSettings\":11, \"notificationsEnabled\":false, \"volume\":30, \"theme\":\"deschisă\"}]";

                //List<Settings> settingsListFromJson = SettingsParser.parseSettings(json);

                //for (Settings settings : settingsListFromJson) {
                 //   settingsDAO.insertSettings(settings);
                //}

                runOnUiThread(() -> Toast.makeText(this, "Setările din JSON au fost salvate!", Toast.LENGTH_SHORT).show());
                loadSettingsFromDatabase();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Eroare la parsarea JSON-ului!", Toast.LENGTH_SHORT).show());
                e.printStackTrace();
            }
        }).start();
    }

    private void saveSettings() {
        boolean notificationsEnabled = switchNotifications.isChecked();
        int volume = seekBarVolume.getProgress();
        String theme = spinnerTheme.getSelectedItem().toString();

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(PREF_NOTIFICATIONS, notificationsEnabled);
        editor.putInt(PREF_VOLUME, volume);
        editor.putString(PREF_THEME, theme);
        editor.apply();

        Settings newSettings = new Settings(notificationsEnabled, volume, theme);

        new Thread(() -> {
            if (isEditing && editSettingId != null) {

                newSettings.setIdSettings(editSettingId);
                settingsDAO.updateSettings(newSettings);
                runOnUiThread(() -> Toast.makeText(this, "Setări actualizate!", Toast.LENGTH_SHORT).show());
            } else {

                settingsDAO.insertSettings(newSettings);
                runOnUiThread(() -> Toast.makeText(this, "Setări salvate!", Toast.LENGTH_SHORT).show());
            }

            loadSettingsFromDatabase();
        }).start();

        resetFields();
    }

    private void loadPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean notificationsEnabled = sharedPreferences.getBoolean(PREF_NOTIFICATIONS, false);
        int volume = sharedPreferences.getInt(PREF_VOLUME, 0);
        String theme = sharedPreferences.getString(PREF_THEME, "Default");

        switchNotifications.setChecked(notificationsEnabled);
        seekBarVolume.setProgress(volume);

        ArrayAdapter<CharSequence> spinnerAdapter = (ArrayAdapter<CharSequence>) spinnerTheme.getAdapter();
        int spinnerPosition = spinnerAdapter.getPosition(theme);
        spinnerTheme.setSelection(spinnerPosition);
    }

    private void loadSettingsFromDatabase() {
        new Thread(() -> {
            List<Settings> allSettings = settingsDAO.getSettings();
            settingsList.clear();
            for (Settings settings : allSettings) {
                settingsList.add("Notificări: " + (settings.isNotificationsEnabled() ? "Activ" : "Inactiv") +
                        ", Volum: " + settings.getVolume() +
                        ", Temă: " + settings.getTheme());
            }
            runOnUiThread(() -> adapter.notifyDataSetChanged());
        }).start();
    }

    private void editSettings(int position) {
        new Thread(() -> {
            List<Settings> allSettings = settingsDAO.getSettings();
            if (position < allSettings.size()) {
                Settings settings = allSettings.get(position);

                runOnUiThread(() -> {
                    switchNotifications.setChecked(settings.isNotificationsEnabled());
                    seekBarVolume.setProgress(settings.getVolume());
                    ArrayAdapter<CharSequence> spinnerAdapter = (ArrayAdapter<CharSequence>) spinnerTheme.getAdapter();
                    int spinnerPosition = spinnerAdapter.getPosition(settings.getTheme());
                    spinnerTheme.setSelection(spinnerPosition);

                    isEditing = true;
                    editSettingId = settings.getIdSettings();
                });
            }
        }).start();
    }

    private void resetFields() {
        switchNotifications.setChecked(false);
        seekBarVolume.setProgress(0);
        spinnerTheme.setSelection(0);
        isEditing = false;
        editSettingId = null;
    }
}
