package com.example.proiect1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity {

    private EditText etOrderDate, etTotalPrice, etDeliveryAddress;
    private Button btnSaveOrder;
    private ListView listViewOrderHistory;
    private OrderHistoryAdapter orderHistoryAdapter;
    private List<Order> orderList;

    private AppDatabase db;
    private OrderDAO orderDAO;
    private UserDAO userDAO;

    private boolean isEditing = false;
    private Long editOrderId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        etOrderDate = findViewById(R.id.etOrderDate);
        etTotalPrice = findViewById(R.id.etTotalPrice);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        btnSaveOrder = findViewById(R.id.btnSaveOrder);
        listViewOrderHistory = findViewById(R.id.listViewOrderHistory);

        db = AppDatabase.getInstance(this);
        orderDAO = db.getOrderDAO();
        userDAO = db.getUserDAO();

        ensureUserExists();
        parseAndSaveOrders();

        orderList = new ArrayList<>();
        orderHistoryAdapter = new OrderHistoryAdapter(this, orderList);
        listViewOrderHistory.setAdapter(orderHistoryAdapter);

        loadOrdersFromDatabase();

        btnSaveOrder.setOnClickListener(v -> {
            String orderDate = etOrderDate.getText().toString().trim();
            String totalPriceStr = etTotalPrice.getText().toString().trim();
            String deliveryAddress = etDeliveryAddress.getText().toString().trim();

            if (orderDate.isEmpty() || totalPriceStr.isEmpty() || deliveryAddress.isEmpty()) {
                Toast.makeText(OrderHistoryActivity.this, "Toate câmpurile sunt obligatorii!", Toast.LENGTH_SHORT).show();
                return;
            }

            double totalPrice;
            try {
                totalPrice = Double.parseDouble(totalPriceStr);
            } catch (NumberFormatException e) {
                Toast.makeText(OrderHistoryActivity.this, "Prețul total trebuie să fie un număr valid!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isEditing) {
                updateOrderInDatabase(orderDate, totalPrice, deliveryAddress);
            } else {
                addOrderToDatabase(orderDate, totalPrice, deliveryAddress);
            }
        });

        listViewOrderHistory.setOnItemClickListener((parent, view, position, id) -> {
            Order order = orderList.get(position);
            enterEditMode(order);
        });

        listViewOrderHistory.setOnItemLongClickListener((parent, view, position, id) -> {
            Order order = orderList.get(position);
            deleteOrderFromDatabase(order);
            return true;
        });
    }

    private void ensureUserExists() {
        new Thread(() -> {
            if (userDAO.getAllUsers().isEmpty()) {
                User defaultUser = new User("Utilizator implicit", "default@example.com", "password", "Default Address");
                userDAO.insertUser(defaultUser);
            }
        }).start();
    }

    private void loadOrdersFromDatabase() {
        new Thread(() -> {
            List<Order> orders = orderDAO.getOrdersForUser(1L);
            System.out.println("DEBUG: Orders loaded - " + orders);
            runOnUiThread(() -> {
                orderList.clear();
                if (orders != null && !orders.isEmpty()) {
                    orderList.addAll(orders);
                    orderHistoryAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(this, "Nu există comenzi de afișat!", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    private void parseAndSaveOrders() {
        new Thread(() -> {
            try {

               // String json = "[{\"idOrders\":6, \"userId\":1, \"orderDate\":\"2024-12-08\", \"totalPrice\":200.5, \"deliveryAddress\":\"Strada 1\"}, " +
                       // "{\"idOrders\":7, \"userId\":1, \"orderDate\":\"2024-12-09\", \"totalPrice\":100.0, \"deliveryAddress\":\"Strada 2\"}]";

               // List<Order> orders = OrderParser.parseOrders(json);

                //for (Order order : orders) {
                  //  orderDAO.insertOrders(order);
                //}

                runOnUiThread(() -> Toast.makeText(this, "Comenzile au fost salvate din JSON!", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Eroare la parsarea JSON-ului!", Toast.LENGTH_SHORT).show());
                e.printStackTrace();
            }
        }).start();
    }

    private void addOrderToDatabase(String orderDate, double totalPrice, String deliveryAddress) {
        new Thread(() -> {
            List<User> users = userDAO.getAllUsers();

            if (users.isEmpty()) {
                User defaultUser = new User("Utilizator implicit", "default@example.com", "password", "Default Address");
                userDAO.insertUser(defaultUser);
                users = userDAO.getAllUsers();
            }

            Long userId = users.get(0).getIdUsers();
            Order newOrder = new Order(userId, orderDate, totalPrice, deliveryAddress);
            orderDAO.insertOrders(newOrder);

            runOnUiThread(() -> {
                Toast.makeText(this, "Comanda a fost adăugată!", Toast.LENGTH_SHORT).show();
                loadOrdersFromDatabase();
                resetFields();
            });
        }).start();
    }

    private void updateOrderInDatabase(String orderDate, double totalPrice, String deliveryAddress) {
        new Thread(() -> {
            Order order = orderDAO.getOrdersForUser(1L).stream()
                    .filter(o -> o.getIdOrders().equals(editOrderId))
                    .findFirst()
                    .orElse(null);

            if (order != null) {
                order.setOrderDate(orderDate);
                order.setTotalPrice(totalPrice);
                order.setDeliveryAddress(deliveryAddress);
                orderDAO.updateOrder(order);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Comanda a fost actualizată!", Toast.LENGTH_SHORT).show();
                    loadOrdersFromDatabase();
                    resetFields();
                });
            }
        }).start();
    }

    private void deleteOrderFromDatabase(Order order) {
        new Thread(() -> {
            orderDAO.deleteOrder(order.getIdOrders());
            runOnUiThread(() -> {
                Toast.makeText(this, "Comanda a fost ștearsă!", Toast.LENGTH_SHORT).show();
                loadOrdersFromDatabase();
            });
        }).start();
    }

    private void enterEditMode(Order order) {
        etOrderDate.setText(order.getOrderDate());
        etTotalPrice.setText(String.valueOf(order.getTotalPrice()));
        etDeliveryAddress.setText(order.getDeliveryAddress());
        isEditing = true;
        editOrderId = order.getIdOrders();
        btnSaveOrder.setText("Actualizează Comanda");
    }

    private void resetFields() {
        etOrderDate.setText("");
        etTotalPrice.setText("");
        etDeliveryAddress.setText("");
        isEditing = false;
        editOrderId = null;
        btnSaveOrder.setText("Adaugă Comanda");
    }
}
