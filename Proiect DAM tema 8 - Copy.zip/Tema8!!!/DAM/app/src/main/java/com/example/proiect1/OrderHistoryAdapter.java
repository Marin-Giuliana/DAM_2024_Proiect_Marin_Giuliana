package com.example.proiect1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class OrderHistoryAdapter extends ArrayAdapter<Order> {
    private final Context context;
    private final List<Order> orders;

    public OrderHistoryAdapter(Context context, List<Order> orders) {
        super(context, R.layout.order_item, orders);
        this.context = context;
        this.orders = orders;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.order_item, parent, false);
        }

        TextView orderDate = convertView.findViewById(R.id.order_date);
        TextView orderPrice = convertView.findViewById(R.id.order_price);
        TextView orderAddress = convertView.findViewById(R.id.order_address);

        Order order = orders.get(position);
        System.out.println("DEBUG: Rendering Order - " + order); // Log pentru debugging

        orderDate.setText(order.getOrderDate());
        orderPrice.setText(String.format("%.2f RON", order.getTotalPrice()));
        orderAddress.setText(order.getDeliveryAddress());

        return convertView;
    }
}
