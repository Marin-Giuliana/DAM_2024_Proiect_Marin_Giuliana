package com.example.proiect1;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private Switch switchNotifications;
    private SeekBar seekBarVolume;
    private Spinner spinnerTheme;
    private Button btnSaveSettings;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> settingsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        switchNotifications = findViewById(R.id.switch_notifications);
        seekBarVolume = findViewById(R.id.seekbar_volume);
        spinnerTheme = findViewById(R.id.spinner_theme);
        btnSaveSettings = findViewById(R.id.btn_save_settings);
        listView = findViewById(R.id.list_view_previous_settings);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.theme_options, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTheme.setAdapter(spinnerAdapter);

        settingsList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, settingsList);
        listView.setAdapter(adapter);

        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean notificationsEnabled = switchNotifications.isChecked();
                int volume = seekBarVolume.getProgress();
                String theme = spinnerTheme.getSelectedItem().toString();
                String settings = "Notificări: " + (notificationsEnabled ? "Activ" : "Inactiv") + ", Volum: " + volume + ", Temă: " + theme;

                settingsList.add(settings);
                adapter.notifyDataSetChanged();

                Toast.makeText(SettingsActivity.this, "Setări salvate cu succes!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
