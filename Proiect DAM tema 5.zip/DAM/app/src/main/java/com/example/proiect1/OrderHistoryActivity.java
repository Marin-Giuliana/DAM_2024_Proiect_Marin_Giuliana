package com.example.proiect1;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.proiect1.Order;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// OrderHistoryAdapter.java
public class OrderHistoryActivity extends AppCompatActivity {

    private EditText etOrderDate, etTotalPrice, etDeliveryAddress;
    private Button btnSaveOrder;
    private ListView listViewOrderHistory;
    private OrderHistoryAdapter orderHistoryAdapter;
    private List<Order> orderList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        etOrderDate = findViewById(R.id.etOrderDate);
        etTotalPrice = findViewById(R.id.etTotalPrice);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        btnSaveOrder = findViewById(R.id.btnSaveOrder);
        listViewOrderHistory = findViewById(R.id.listViewOrderHistory);
        orderList = new ArrayList<>();
        orderHistoryAdapter = new OrderHistoryAdapter(this, orderList);
        listViewOrderHistory.setAdapter(orderHistoryAdapter);
        btnSaveOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String orderDate = etOrderDate.getText().toString().trim();
                String totalPriceStr = etTotalPrice.getText().toString().trim();
                String deliveryAddress = etDeliveryAddress.getText().toString().trim();

                if (orderDate.isEmpty() || totalPriceStr.isEmpty() || deliveryAddress.isEmpty()) {
                    Toast.makeText(OrderHistoryActivity.this, "Toate câmpurile sunt obligatorii!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double totalPrice;
                try {
                    totalPrice = Double.parseDouble(totalPriceStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(OrderHistoryActivity.this, "Prețul total trebuie să fie un număr valid!", Toast.LENGTH_SHORT).show();
                    return;
                }

                Order newOrder = new Order(orderDate, totalPrice, deliveryAddress);
                orderList.add(newOrder);
                orderHistoryAdapter.notifyDataSetChanged();
                etOrderDate.setText("");
                etTotalPrice.setText("");
                etDeliveryAddress.setText("");
            }
        });
    }
}
