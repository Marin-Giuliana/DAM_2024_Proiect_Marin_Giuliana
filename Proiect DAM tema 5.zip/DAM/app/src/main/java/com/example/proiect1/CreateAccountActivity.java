package com.example.proiect1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText etName, etPname, etEmail, etPassword, etAdress;
    private Button btnCreazaCont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        etName = findViewById(R.id.etName);
        etPname = findViewById(R.id.etPname);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etAdress = findViewById(R.id.etAdress);
        btnCreazaCont = findViewById(R.id.btnCreazaCont);

        btnCreazaCont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String pname = etPname.getText().toString();
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String adress = etAdress.getText().toString();

                User user = new User(name + " " + pname, email, password, adress);

                Intent intent = new Intent();
                intent.putExtra("user", user);
                setResult(RESULT_OK, intent);
                Toast.makeText(CreateAccountActivity.this, "Utilizator creat cu succes!", Toast.LENGTH_SHORT).show();

                finish();
            }
        });
    }
}
