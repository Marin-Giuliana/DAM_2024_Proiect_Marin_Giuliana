package com.example.proiect1;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDAO {
    @Insert
    void insertUser(User user);

    @Transaction
    @Query("SELECT * FROM Users WHERE idUsers = :userId")
    UserWithOrders getUserWithOrders(Long userId);

    @Query("SELECT * FROM Users")
    List<User> getAllUsers();

    @Update
    void updateUser(User user);
    @Query("DELETE FROM Users WHERE idUsers = :userId")
    void deleteUser(Long userId);
}
