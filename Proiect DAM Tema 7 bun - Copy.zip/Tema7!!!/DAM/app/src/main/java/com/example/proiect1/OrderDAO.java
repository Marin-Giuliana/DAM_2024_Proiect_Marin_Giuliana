package com.example.proiect1;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface OrderDAO {

    @Insert
    void insertOrders(Order order);

    @Query("SELECT * FROM Orders WHERE userId = :userId")
    List<Order> getOrdersForUser(Long userId);

    @Update
    void updateOrder(Order order);
    @Query("DELETE FROM Orders WHERE idOrders = :orderId")
    void deleteOrder(Long orderId);

}
