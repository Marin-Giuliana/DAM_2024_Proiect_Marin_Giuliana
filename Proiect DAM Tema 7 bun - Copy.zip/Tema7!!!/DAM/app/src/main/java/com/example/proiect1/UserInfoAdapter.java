package com.example.proiect1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class UserInfoAdapter extends BaseAdapter {
    private final Context context;
    private final List<User> userList;

    public UserInfoAdapter(Context context, List<User> userList) {
        this.context = context;
        this.userList = userList;
    }

    @Override
    public int getCount() {
        return userList.size();
    }

    @Override
    public Object getItem(int position) {
        return userList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.user_item, parent, false);
        }

        TextView userName = convertView.findViewById(R.id.user_name);
        TextView userEmail = convertView.findViewById(R.id.user_email);

        User user = userList.get(position);
        userName.setText(user.getName());
        userEmail.setText(user.getEmail());

        return convertView;
    }
}
