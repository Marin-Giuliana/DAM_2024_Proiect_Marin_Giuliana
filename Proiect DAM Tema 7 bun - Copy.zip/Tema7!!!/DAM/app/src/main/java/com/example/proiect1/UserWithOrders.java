package com.example.proiect1;

import androidx.room.Embedded;
import androidx.room.Relation;

import java.util.List;

public class UserWithOrders {

    @Embedded
    private User user;

    @Relation(
            parentColumn = "idUsers",
            entityColumn = "userId"
    )
    private List<Order> orders;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }

}
