package com.example.proiect1;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "Users")
public class User implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private Long idUsers;
    private String name;
    private String email;
    private String password;
    private String deliveryAdress;
    public User(String name, String email, String password, String deliveryAdress) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.deliveryAdress = deliveryAdress;
    }

    public Long getIdUsers() {
        return idUsers;
    }

    public void setIdUsers(Long idUsers) {
        this.idUsers = idUsers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDeliveryAdress() {
        return deliveryAdress;
    }

    public void setDeliveryAdress(String deliveryAdress) {
        this.deliveryAdress = deliveryAdress;
    }

    @Override
    public String toString() {
        return "User{" +
                "idUsers=" + idUsers +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", deliveryAdress='" + deliveryAdress + '\'' +
                '}';
    }
}
