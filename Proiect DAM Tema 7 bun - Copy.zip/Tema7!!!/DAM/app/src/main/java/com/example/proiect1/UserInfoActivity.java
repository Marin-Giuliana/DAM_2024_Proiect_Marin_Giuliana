package com.example.proiect1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class UserInfoActivity extends AppCompatActivity {

    private EditText etName, etEmail;
    private Button btnSubmit;
    private ListView listView;
    private UserInfoAdapter adapter;
    private List<User> userList;

    private AppDatabase db;
    private UserDAO userDAO;

    private boolean isEditing = false;
    private Long editUserId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        btnSubmit = findViewById(R.id.btn_submit);
        listView = findViewById(R.id.list_view_user_history);

        db = AppDatabase.getInstance(this);
        userDAO = db.getUserDAO();

        userList = new ArrayList<>();
        adapter = new UserInfoAdapter(this, userList);
        listView.setAdapter(adapter);

        loadUsersFromDatabase();

        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty()) {
                Toast.makeText(UserInfoActivity.this, "Toate câmpurile sunt obligatorii!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isEditing) {
                updateUserInDatabase(name, email);
            } else {
                User newUser = new User(name, email, "default_password", "default_address");
                addUserToDatabase(newUser);
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            User user = userList.get(position);
            enterEditMode(user);
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            deleteUserFromDatabase(userList.get(position));
            return true;
        });
    }

    private void loadUsersFromDatabase() {
        new Thread(() -> {
            List<User> users = userDAO.getAllUsers();
            runOnUiThread(() -> {
                userList.clear();
                userList.addAll(users);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }

    private void addUserToDatabase(User user) {
        new Thread(() -> {
            userDAO.insertUser(user);
            runOnUiThread(() -> {
                Toast.makeText(this, "Utilizator adăugat!", Toast.LENGTH_SHORT).show();
                loadUsersFromDatabase();
                resetFields();
            });
        }).start();
    }

    private void updateUserInDatabase(String name, String email) {
        new Thread(() -> {
            User user = userDAO.getUserWithOrders(editUserId).getUser();
            user.setName(name);
            user.setEmail(email);

            userDAO.updateUser(user);
            runOnUiThread(() -> {
                Toast.makeText(this, "Utilizator actualizat!", Toast.LENGTH_SHORT).show();
                loadUsersFromDatabase();
                resetFields();
            });
        }).start();
    }

    private void deleteUserFromDatabase(User user) {
        new Thread(() -> {
            userDAO.deleteUser(user.getIdUsers());
            runOnUiThread(() -> {
                Toast.makeText(this, "Utilizator șters!", Toast.LENGTH_SHORT).show();
                loadUsersFromDatabase();
            });
        }).start();
    }

    private void enterEditMode(User user) {
        etName.setText(user.getName());
        etEmail.setText(user.getEmail());
        isEditing = true;
        editUserId = user.getIdUsers();
        btnSubmit.setText("Actualizează Utilizator");
    }

    private void resetFields() {
        etName.setText("");
        etEmail.setText("");
        isEditing = false;
        editUserId = null;
        btnSubmit.setText("Adaugă Utilizator");
    }
}