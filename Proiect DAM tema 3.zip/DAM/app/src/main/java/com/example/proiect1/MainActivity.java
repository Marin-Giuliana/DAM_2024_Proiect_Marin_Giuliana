package com.example.proiect1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etUtilizator;
    EditText etParola;
    Button btnHelp;
    Button btnContNou;
    Button btnConecteaza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etUtilizator = findViewById(R.id.etTEA);
        etParola = findViewById(R.id.etTP);
        btnConecteaza = findViewById(R.id.btnLogIn);
        btnContNou = findViewById(R.id.btnSignUp);
        btnHelp = findViewById(R.id.btnHelp);

        // Creează cont nou
        btnContNou.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });

        // Ajutor
        btnHelp.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HelpActivity.class);
            startActivity(intent);
        });

        // Conectează-te (deschide activitatea goală cu butonul + în colț)
        btnConecteaza.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EmptyActivity.class);
            startActivity(intent);
        });
    }
}
