package com.example.proiect1;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.widget.PopupMenu;

public class EmptyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);

        // Inițializează FloatingActionButton (butonul flotant +)
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Creează și inițializează PopupMenu
                PopupMenu popup = new PopupMenu(EmptyActivity.this, view);
                MenuInflater inflater = popup.getMenuInflater();
                // Umflă meniul definit în res/menu/menu.xml
                inflater.inflate(R.menu.menu, popup.getMenu());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        int id = item.getItemId();

                        if (id == R.id.menu_user_info) {
                            Intent intent = new Intent(EmptyActivity.this, UserInfoActivity.class);
                            startActivity(intent);
                            return true;
                        } else if (id == R.id.menu_order_history) {
                            Intent intent = new Intent(EmptyActivity.this, OrderHistoryActivity.class);
                            startActivity(intent);
                            return true;
                        } else if (id == R.id.menu_settings) {
                            Intent intent = new Intent(EmptyActivity.this, SettingsActivity.class);
                            startActivity(intent);
                            return true;
                        }
                        return false;
                    }
                });

                // Afișează meniul pop-up
                popup.show();
            }
        });
    }
}
