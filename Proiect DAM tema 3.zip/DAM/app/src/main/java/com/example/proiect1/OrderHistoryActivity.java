package com.example.proiect1;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        // Inițializează RecyclerView pentru a afișa istoricul comenzilor
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Exemplu de date pentru istoricul comenzilor
        List<String> orderList = new ArrayList<>();
        orderList.add("Comanda #1: Trandafir criogenat (540 ron)");
        orderList.add("Comanda #2: 1 buchet de trandafiri (120 ron)");
        orderList.add("Comanda #3: 2 buchete de lalele (150 ron)");

        // Inițializează și setează adapterul RecyclerView
        OrderHistoryAdapter adapter = new OrderHistoryAdapter(orderList);
        recyclerView.setAdapter(adapter);
    }
}
