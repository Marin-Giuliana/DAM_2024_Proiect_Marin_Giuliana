package com.example.proiect1;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private Switch switchNotifications;
    private SeekBar seekBarVolume;
    private Spinner spinnerTheme;
    private Button btnSaveSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Inițializează elementele vizuale
        switchNotifications = findViewById(R.id.switch_notifications);
        seekBarVolume = findViewById(R.id.seekbar_volume);
        spinnerTheme = findViewById(R.id.spinner_theme);
        btnSaveSettings = findViewById(R.id.btn_save_settings);

        // Populează Spinner-ul cu opțiuni
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.theme_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTheme.setAdapter(adapter);

        // Setează un listener pentru butonul de salvare
        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obține valorile din câmpuri
                boolean notificationsEnabled = switchNotifications.isChecked();
                int volume = seekBarVolume.getProgress();
                String selectedTheme = spinnerTheme.getSelectedItem().toString();

                // Afișează un mesaj cu valorile setărilor
                Toast.makeText(SettingsActivity.this, "Setări salvate:\n" +
                        "Notificări: " + notificationsEnabled + "\n" +
                        "Volum: " + volume + "\n" +
                        "Tema: " + selectedTheme, Toast.LENGTH_LONG).show();
            }
        });
    }
}
