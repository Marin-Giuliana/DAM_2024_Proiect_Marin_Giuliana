package com.example.proiect1;

import java.io.Serializable;

public class Settings implements Serializable {
    private boolean notificationsEnabled;
    private int volume;
    private String theme;


    public Settings(boolean notificationsEnabled, int volume, String theme) {
        this.notificationsEnabled = notificationsEnabled;
        this.volume = volume;
        this.theme = theme;
    }

    public boolean isNotificationsEnabled() {
        return notificationsEnabled;
    }

    public int getVolume() {
        return volume;
    }

    public String getTheme() {
        return theme;
    }

    public void setNotificationsEnabled(boolean notificationsEnabled) {
        this.notificationsEnabled = notificationsEnabled;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    @Override
    public String toString() {
        return "Settings{" +
                "Notificări active =" + notificationsEnabled +
                ", Volum notificări =" + volume +
                ", Temă ='" + theme + '\'' +
                '}';
    }
}

