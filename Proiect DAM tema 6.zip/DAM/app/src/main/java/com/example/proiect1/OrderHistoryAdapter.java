package com.example.proiect1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;

import com.example.proiect1.R;

import java.util.ArrayList;
import java.util.List;

public class OrderHistoryAdapter extends RecyclerView.Adapter<OrderHistoryAdapter.ViewHolder> {

    private final List<String> orderList;
    private final List<String> fullOrderList;

    public OrderHistoryAdapter(List<String> orderList) {
        if (orderList == null) {
            this.orderList = new ArrayList<>();
            this.fullOrderList = new ArrayList<>();
        } else {
            this.orderList = new ArrayList<>(orderList);
            this.fullOrderList = new ArrayList<>(orderList);
        }
    }

    public void addOrder(String order) {
        orderList.add(order);
        fullOrderList.add(order);
        notifyItemInserted(orderList.size() - 1); // Notifică doar pentru elementul nou adăugat
    }

    public void filter(String query) {
        orderList.clear();

        if (query == null || query.isEmpty()) {
            orderList.addAll(fullOrderList);
        } else {
            String lowerCaseQuery = query.toLowerCase();
            for (String order : fullOrderList) {
                if (order.toLowerCase().contains(lowerCaseQuery)) {
                    orderList.add(order);
                }
            }
        }

        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String order = orderList.get(position);
        holder.orderTextView.setText(order);
        Log.d("OrderHistoryAdapter", "Afișare comandă: " + order);
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView orderTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            orderTextView = itemView.findViewById(R.id.order_text);
        }
    }
}
