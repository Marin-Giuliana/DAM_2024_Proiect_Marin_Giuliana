package com.example.proiect1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class OrderHistoryActivity extends AppCompatActivity {

    private EditText etOrderDate, etTotalPrice, etDeliveryAddress;
    private Button btnSaveOrder;
    private RecyclerView rvOrderList;

    private ArrayList<String> orderHistoryList;
    private OrderHistoryAdapter orderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        etOrderDate = findViewById(R.id.etOrderDate);
        etTotalPrice = findViewById(R.id.etTotalPrice);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        btnSaveOrder = findViewById(R.id.btnSaveOrder);
        rvOrderList = findViewById(R.id.rvOrderList);

        // Inițializează lista de comenzi și adapterul RecyclerView
        orderHistoryList = new ArrayList<>();
        orderAdapter = new OrderHistoryAdapter(orderHistoryList);
        rvOrderList.setLayoutManager(new LinearLayoutManager(this));
        rvOrderList.setAdapter(orderAdapter);

        btnSaveOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String orderDate = etOrderDate.getText().toString();
                String totalPriceText = etTotalPrice.getText().toString();
                String deliveryAddress = etDeliveryAddress.getText().toString();

                if (orderDate.isEmpty() || totalPriceText.isEmpty() || deliveryAddress.isEmpty()) {
                    Toast.makeText(OrderHistoryActivity.this, "Toate câmpurile sunt necesare!", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        double totalPrice = Double.parseDouble(totalPriceText);
                        String orderDetails = "Data: " + orderDate + ", Preț: " + totalPrice + ", Adresă: " + deliveryAddress;
                        orderHistoryList.add(orderDetails);
                        orderAdapter.notifyDataSetChanged(); // Actualizează RecyclerView-ul
                        etOrderDate.setText("");
                        etTotalPrice.setText("");
                        etDeliveryAddress.setText("");
                        Toast.makeText(OrderHistoryActivity.this, "Comandă adăugată în istoric", Toast.LENGTH_SHORT).show();

                        // Pregătește datele pentru a fi transmise înapoi, dacă este necesar
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("order", orderDetails);

                    } catch (NumberFormatException e) {
                        Toast.makeText(OrderHistoryActivity.this, "Introduceți un preț valid!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
