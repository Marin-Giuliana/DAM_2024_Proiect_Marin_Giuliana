package com.example.proiect1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etUtilizator;
    private EditText etParola;
    private Button btnHelp;
    private Button btnContNou;
    private Button btnConecteaza;
    private final ActivityResultLauncher<Intent> createAccountLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    User user = (User) result.getData().getSerializableExtra("user");
                    TextView textViewUserDetails = findViewById(R.id.text_view_user_details);
                    textViewUserDetails.setText("Detalii utilizator:\n" + user.toString());
                }
            });

    private final ActivityResultLauncher<Intent> emptyActivityLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();
                    if (data.hasExtra("order")) {
                        Order order = (Order) data.getSerializableExtra("order");
                        TextView textViewOrderDetails = findViewById(R.id.text_view_order_details);
                        textViewOrderDetails.setText("Detalii comandă:\n" + order.toString());
                    }
                    if (data.hasExtra("settings")) {
                        Settings settings = (Settings) data.getSerializableExtra("settings");
                        TextView textViewSettingsDetails = findViewById(R.id.text_view_settings_details);
                        textViewSettingsDetails.setText("Detalii setări:\n" + settings.toString());
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etUtilizator = findViewById(R.id.etTEA);
        etParola = findViewById(R.id.etTP);
        btnConecteaza = findViewById(R.id.btnLogIn);
        btnContNou = findViewById(R.id.btnSignUp);
        btnHelp = findViewById(R.id.btnHelp);
        btnContNou.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
            createAccountLauncher.launch(intent);
        });

        btnHelp.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HelpActivity.class);
            startActivity(intent);
        });

        btnConecteaza.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EmptyActivity.class);
            emptyActivityLauncher.launch(intent);
        });
    }
}
