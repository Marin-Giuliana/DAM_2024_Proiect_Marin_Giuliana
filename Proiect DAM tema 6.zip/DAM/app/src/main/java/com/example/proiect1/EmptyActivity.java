package com.example.proiect1;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class EmptyActivity extends AppCompatActivity {

    private FloatingActionButton fab;
    private final ActivityResultLauncher<Intent> settingsLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtras(result.getData().getExtras());
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            });
    private final ActivityResultLauncher<Intent> orderLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtras(result.getData().getExtras());
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(this::showPopupMenu);
    }
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(this::onMenuItemClick);
        popupMenu.show();
    }
    private boolean onMenuItemClick(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.menu_settings) {
            Intent intentSettings = new Intent(EmptyActivity.this, SettingsActivity.class);
            settingsLauncher.launch(intentSettings);
            return true;
        } else if (itemId == R.id.menu_order_history) {
            Intent intentOrder = new Intent(EmptyActivity.this, OrderHistoryActivity.class);
            orderLauncher.launch(intentOrder);
            return true;
        } else if (itemId == R.id.menu_user_info) {
            return true;
        }
        return false;
    }
}
