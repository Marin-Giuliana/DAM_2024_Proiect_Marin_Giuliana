package com.example.proiect1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class OrderHistoryActivity extends AppCompatActivity {

    private EditText etOrderDate, etTotalPrice, etDeliveryAddress;
    private Button btnSaveOrder;
    private ListView listViewOrderHistory;

    private ArrayList<String> orderHistoryList;
    private ArrayAdapter<String> orderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        etOrderDate = findViewById(R.id.etOrderDate);
        etTotalPrice = findViewById(R.id.etTotalPrice);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        btnSaveOrder = findViewById(R.id.btnSaveOrder);
        listViewOrderHistory = findViewById(R.id.listViewOrderHistory);

        orderHistoryList = new ArrayList<>();
        orderAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, orderHistoryList);
        listViewOrderHistory.setAdapter(orderAdapter);

        btnSaveOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String orderDate = etOrderDate.getText().toString();
                String totalPriceText = etTotalPrice.getText().toString();
                String deliveryAddress = etDeliveryAddress.getText().toString();

                if (orderDate.isEmpty() || totalPriceText.isEmpty() || deliveryAddress.isEmpty()) {
                    Toast.makeText(OrderHistoryActivity.this, "Toate câmpurile sunt necesare!", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        double totalPrice = Double.parseDouble(totalPriceText);
                        Order order = new Order(orderDate, totalPrice, deliveryAddress);
                        String orderDetails = "Data: " + orderDate + ", Preț: " + totalPrice + ", Adresă: " + deliveryAddress;
                        orderHistoryList.add(orderDetails);
                        orderAdapter.notifyDataSetChanged();
                        etOrderDate.setText("");
                        etTotalPrice.setText("");
                        etDeliveryAddress.setText("");
                        Toast.makeText(OrderHistoryActivity.this, "Comandă adăugată în istoric", Toast.LENGTH_SHORT).show();
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("order", order);
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    } catch (NumberFormatException e) {
                        Toast.makeText(OrderHistoryActivity.this, "Introduceți un preț valid!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
