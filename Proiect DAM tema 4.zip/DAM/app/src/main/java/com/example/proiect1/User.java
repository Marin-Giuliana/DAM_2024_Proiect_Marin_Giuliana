package com.example.proiect1;

import java.io.Serializable;

public class User implements Serializable {
    private String name;
    private String email;
    private String password;
    private String deliveryAdress;
    public User(String name, String email, String password, String deliveryAdress) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.deliveryAdress = deliveryAdress;
    }


    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getDeliveryAdress() {
        return deliveryAdress;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setDeliveryAdress(String deliveryAdress) {
        this.deliveryAdress = deliveryAdress;
    }

    @Override
    public String toString() {
        return "User{" +
                "Nume ='" + name + '\'' +
                ", Email ='" + email + '\'' +
                ", Parola ='" + password + '\'' +
                ", Adresa livrare ='" + deliveryAdress + '\'' +
                '}';
    }
}
